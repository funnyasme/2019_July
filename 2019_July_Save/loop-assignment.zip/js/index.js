// 1.   Have a user enter numbers repeatedly until -1 is entered. In the end, display how many times the user has entered odd number
//INCLUDE COMMENTS

/*

var num, times;  // creating variables: num for the number user enters, times to keep track of how many times an odd number was entered
num = 0;         // initial value = 0 for both variables
times = 0;

while (num != -1){      // repeats to enter a number until -1 is entered
  num = parseFloat(prompt("Enter a number"));
  if (num % 2 != 0  &&  num != -1){  // if the number is odd and not equal to -1 keep going and add 1 to times each time this is true
  times++;
  }
}

document.write("Number of times you entered odd number: " + times);  // to show user number of times they entered odd number

*/



//  2.  How many times do you have to roll a pair of dice before they come up snake eyes? Write a computer program that uses a while loop to simulate this experiment. The program should report the number of rolls that it makes before the dice come up snake eyes.

 // 1st way to solve #2
/*
var dice_1, dice_2, counter, gotU; // dice_1 for its roll result, dice_2 for its roll result, counter to count how many times dice were rolled before they came up with snake eyes, gotU to keep track that if snake eyes are rolled, they have been "gotten"/achieved(useful in while loop)

dice_1 = 0;  // initializing each variable value with 0 
dice_2 = 0;
counter = 0;
gotU = 0;     

while (gotU == 0) {   // while snake eyes have not been gotten, keep generating a random integer from 1-6
  dice_1 = Math.ceil(6*Math.random());//generate random integer # 1,2,3,4,5,6
  dice_2 = Math.ceil(6*Math.random());//generate random integer # 1,2,3,4,5,6
  document.write (dice_1 + " " + dice_2 + "<br>"); //print the roll results
  if (dice_1 == 1 && dice_2 == 1) {  // if the roll results of the dice are both 1, the gotU variable adds 1 because snake eyes have been achieved
     gotU = 1;
  }
  counter++; // keeping track of how many times dice were rolled
}

document.write ("After " + counter + " rolls, you rolled snake eyes"); //shows user how many rolls they did until snake eyes

*/


  
// another way to solve #2

/*

var dice_1, dice_2, counter; // dice_1 for its roll result, dice_2 for its roll result, counter to count how many times dice were rolled before they came up with snake eyes
dice_1 = 0;  // initializing each variable value with 0 
dice_2 = 0;
counter = 0;

//while (dice_1 != 1 || dice_2 != 1) {    another way
while (!(dice_1 == 1 && dice_2 == 1)) {  // while snake eyes have not occured, keep generating a random integer from 1-6 for each die
  dice_1 = Math.ceil(6*Math.random());//generate random integer # 1,2,3,4,5,6
  dice_2 = Math.ceil(6*Math.random());//generate random integer # 1,2,3,4,5,6
  document.write (dice_1 + " " + dice_2 + "<br>");  // print the rolled results for each die
  counter++; // add one to counter variable each time to keep track of how many times dice were rolled
}

document.write ("After " + counter + " rolls, you rolled snake eyes"); 
// shows user after how many rolls they achieved snake eyes


*/



// 3. (Guessing a number game). Repeatedly ask the user to guess a number between 1 and 50. After he enters the number, the program should display if the number is “too high” or “too low”. If the user enters the correct number, exit the loop and display the number of guesses. If the user doesn’t guess the number after 6 guesses, exit the loop, show “You lose” and display the secret number


/*

var cnum, num, counter;  //cnum is the random integer that the computer secretly picks, num is the integer that the user enters, counter keeps track of the number of guesses
num=-1;  // just giving a value to num
cnum=Math.ceil(Math.random()*50);  // cnum generating a random integer from 1-50
counter = 1;     // counter starts counting at 1
alert(cnum);      // showing user the secret number so they have a way to exit the game if they want 

while (num != cnum && counter <= 6){  //while the user's guessed number is not equal to the computer's number and the counter is less than or equal to 6, keep ask the user to enter a number between 1 and 50
  num = parseInt(prompt("Enter a number between 1 and 50"));
  if (num < cnum){   // if the guess is less than the actual number, show the user it's too low
    alert("Too low");  
  }
  else if (num > cnum){  // else if the guess is higher than the actual number, show the user it's too high
    alert("Too high");
  }
  counter++;    // add 1 to the counter(# of guesses)
}
if(num == cnum){  // if the number is equal to the computer's number, show user how many times they guessed by doing counter-1, which shows the # of guesses since counter started with an initial value of 1 in the start of the program
  document.write("You guessed this many times: " + (counter-1));
}
else{   // if the user guessed 6 times already and still didn't get the number, tell them they lose and what the secret # was.
  document.write("You guessed 6 times. You Lose. The number was: "+cnum);
}

*/


// 4. (Man vs Computer -Rock-paper-scissors game). Write a Rock-Paper-Scissors program where the user will be playing versus the computer. Repeat the game until either the user or the computer wins 3 points (tie=0 points, win=1 point).  Hint: Generate a random number (1,2 or 3). 1-Rock, 2-Paper, 3-Scissors 

/*


var comp, player, winComp, winPlayer; // comp is the random choice the computer makes of rock(1), paper(2), or scissors(3). player is the choice of the user. winComp is the score tracker of the computer, and winPlayer is the score tracker of the player.
winComp = 0;  // the scoretracker variables both start with a score of 0
winPlayer = 0;

while (winComp < 3 && winPlayer < 3){  // while the score of the computer and user are both less than 3, keep making the computer generate a random number, and the player choose their number(1,2, or 3 for player and computer)
  comp = Math.ceil(3*Math.random());
  player = parseInt(prompt("Enter 1(rock), 2(paper), or 3(scissors)"));

  while (player > 3 || player < 1 || isNaN(player)){  //while the user enters a number greater than 3 or less than 1, or nothing(NaN), tell user the input is wrong and enter the options 1, 2, or 3.
    player = parseInt(prompt("wrong input. Enter 1(rock), 2(paper), or 3(scissors)"));
  }
  
  if (comp == player){ //if the computer and player are tied, show the computer's number that it chose, the player's number that they chose and say it is a tie in alert form, then keep it recorded in document.write form (so it can be viewed during the game and after the game).
    alert("comp = " + comp + "   player = " + player + " it is a tie.");
    document.write("comp = " + comp + "   player = " + player + " it is a tie." + "<br>");
  }
  else if (comp - player == 1 || comp - player == -2){ //else if it's not a tie, if the computer's choice minus player's choice is 1 or -2, computer wins.
    winComp++; //increasing points of computer by 1
    alert("comp = " + comp + "   player = " + player + " Computer wins."); //showing in alert form the computer's choice, player's choice, and the fact that the computer won that round.
    document.write("comp = " + comp + "   player = " + player + " Computer wins. " + "<br>");  //recording and showing in document.write form(at end of game) the same thing the alert above displayed.
  }
  else {  // else, the player wins the round
    winPlayer++; // increase points of player by 1
    alert("comp = " + comp + "   player = " + player + " Player wins. "); //displaying in alert form the computer's and player's choice, and the fact that the player won that round.
    document.write("comp = " + comp + "   player = " + player + " Player wins. " + "<br>"); //displaying same thing above in document.write form
  } 
}

if (winPlayer == 3){  // if the player's total points are 3, then the player wins overall.
  document.write("Finally Player wins"); // displaying that the player won overall
}
else{   // if the computer's total points are 3, then the computer wins overall.
  document.write("Finally Computer wins"); // displaying that the computer won overall
}


*/



// By: Chitralekha Basu